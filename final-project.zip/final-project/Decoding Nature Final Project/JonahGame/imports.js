var jonahSimplex = require("simplex-noise")

window.jonahSimplex = new jonahSimplex()
