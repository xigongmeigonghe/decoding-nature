var RobertGame = new RobertGame();


function setup() {
  RobertGame.preload();
  RobertGame.setup();
}

function draw() {
  RobertGame.run();
}
