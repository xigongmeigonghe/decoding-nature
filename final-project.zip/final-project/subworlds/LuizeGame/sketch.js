var luizeGame = new LuizeGame();

function setup() {
  luizeGame.setup();
}

function draw() {
  luizeGame.run();
}
