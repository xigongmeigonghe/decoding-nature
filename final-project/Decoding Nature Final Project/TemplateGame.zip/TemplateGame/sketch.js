var game = new Game();

function setup() {
  game.setup();
}

function draw() {
  game.run();
}
